"""Main training loop for Nori CCMM training."""

from __future__ import annotations

import copy
import json
import random
import os
import stat
import tempfile
import time
import math
import warnings
from collections import defaultdict
from contextlib import nullcontext
from pathlib import Path

import numpy as np
import torch
from torch.amp import GradScaler

from synthefy_nori.training.config import TrainingConfig
from synthefy_nori.training.data_generator import (
    SyntheticDataFilterError,
    generate_batch,
)
from synthefy_nori.training.masking import create_masks, random_mask_type, random_mask_ratio
from synthefy_nori.training.loss import compute_ccmm_loss
from synthefy_nori.training.optim import build_optimizer
from synthefy_nori.training.prefetch import DataPrefetcher


class ICLFilterExhaustedError(RuntimeError):
    """The configured ICL gate could not fill a clean training batch."""


def _foreach_ema_update(
    ema_state: dict[str, torch.Tensor],
    current_state: dict[str, torch.Tensor],
    decay: float,
) -> None:
    # Update EMA tensors in device/dtype groups instead of scalar kernels.
    floating_groups: dict[
        tuple[torch.device, torch.dtype],
        tuple[list[torch.Tensor], list[torch.Tensor]],
    ] = defaultdict(lambda: ([], []))
    nonfloating_pairs: list[tuple[torch.Tensor, torch.Tensor]] = []

    for name, tensor in current_state.items():
        ema_tensor = ema_state[name]
        if torch.is_floating_point(tensor):
            ema_tensors, current_tensors = floating_groups[(tensor.device, tensor.dtype)]
            ema_tensors.append(ema_tensor)
            current_tensors.append(tensor.detach())
        else:
            nonfloating_pairs.append((ema_tensor, tensor))

    for ema_tensors, current_tensors in floating_groups.values():
        torch._foreach_mul_(ema_tensors, decay)
        torch._foreach_add_(ema_tensors, current_tensors, alpha=1.0 - decay)
    for ema_tensor, tensor in nonfloating_pairs:
        ema_tensor.copy_(tensor)


def get_wcd_schedule(optimizer, warmup_steps, decay_start_step, total_steps, lr_min):
    """Warmup → Constant → Cosine Decay schedule.

    When decay_start_step <= warmup_steps (default 0), decay starts right
    after warmup — identical to the old cosine-with-warmup behavior.
    """
    # If decay_start_step is before warmup ends, start decay right after warmup
    effective_decay_start = max(decay_start_step, warmup_steps)

    def lr_lambda(step):
        if step < warmup_steps:
            return step / max(warmup_steps, 1)
        if step < effective_decay_start:
            return 1.0
        progress = (step - effective_decay_start) / max(total_steps - effective_decay_start, 1)
        cosine_decay = 0.5 * (1 + math.cos(math.pi * progress))
        return max(lr_min / optimizer.defaults["lr"], cosine_decay)

    return torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda)


class NoriTrainer:
    """Training loop for Nori with CCMM objective."""

    def __init__(self, model, config: TrainingConfig, model_config: dict = None, on_checkpoint_saved=None):
        self.model = model
        self.config = config
        self.model_config = model_config
        self.on_checkpoint_saved = on_checkpoint_saved
        self.device = torch.device(config.device)

        # In DDP mode, model is already on device from the training entrypoint
        if not config.distributed:
            self.model.to(self.device)

        # Rank-0 flag for logging/checkpointing
        self.is_main = config.rank == 0

        # ``min_*``/``max_*`` bound the continuous draw, but the physical
        # tables are bucketed.  Resolve that finite support once, fail early if
        # the requested range contains no supported shape, and expose the
        # actual endpoints in logs instead of implying that unreachable raw
        # endpoints are trained.
        self.effective_shape_support = self._resolve_effective_shape_support(config)
        if self.is_main:
            support = self.effective_shape_support
            print(
                "Effective bucketed shape support: "
                f"rows={support['min_samples']}..{support['max_samples']} "
                f"({len(support['sample_buckets'])} buckets), "
                f"features={support['min_features']}..{support['max_features']} "
                f"({len(support['feature_buckets'])} buckets), "
                f"shapes={len(support['shapes'])}"
            )

        # Optimizer
        self.optimizer, optimizer_stats = build_optimizer(
            self.model.named_parameters(),
            optimizer_name=config.optimizer,
            lr=config.lr,
            weight_decay=config.weight_decay,
            betas=config.betas,
            muon_momentum=config.muon_momentum,
            muon_nesterov=config.muon_nesterov,
            muon_adjust_lr_fn=config.muon_adjust_lr_fn,
            muon_include_embeddings=config.muon_include_embeddings,
            muon_include_nd=config.muon_include_nd,
        )
        if self.is_main:
            print(
                f"Optimizer: {config.optimizer} "
                f"(muon_tensors={optimizer_stats['muon_tensors']}, "
                f"adamw_tensors={optimizer_stats['adamw_tensors']})"
            )

        # Scheduler
        self.scheduler = get_wcd_schedule(
            self.optimizer,
            config.warmup_steps,
            config.decay_start_step,
            config.total_steps,
            config.lr_min,
        )

        # Mixed precision — use bf16 (not fp16).
        # fp16 max is 65504; the MLP normal_(std=1) init + post-norm cause
        # gradient overflow in fp16.  bf16 has the same exponent range as fp32.
        # GradScaler is unnecessary for bf16 (no overflow/underflow risk).
        self.scaler = GradScaler("cuda", enabled=False)

        # RNG — shared RNG for data shape/task/eval_pos (identical across ranks
        # so all GPUs get the same n_samples, n_features, task_type, n_classes,
        # eval_pos). Per-rank RNG for actual data generation and masking.
        # IMPORTANT: all shared_rng consumption must happen at the TOP of
        # train_step, before any error-prone code, to stay in sync across ranks.
        self.shared_rng = np.random.default_rng(config.seed)
        self.rng = np.random.default_rng(config.seed + config.rank)

        # State
        self.global_step = 0
        self.optimizer_step = 0
        self.accumulated_micro_steps = 0
        self.best_loss = float("inf")

        # Loss spike detection (EMA-based)
        self._loss_ema = None
        self._loss_ema_alpha = 0.01  # slow-moving average
        self._loss_spike_threshold = 10.0  # skip if loss > threshold * EMA
        self.ema_decay = float(config.ema_decay)
        self.ema_state_dict = None
        if 0.0 < self.ema_decay < 1.0:
            self.ema_state_dict = {
                name: tensor.detach().clone() for name, tensor in self._get_bare_model().state_dict().items()
            }
            if self.is_main:
                print(f"EMA enabled: decay={self.ema_decay}")

        # Optional mined synthetic quality rules.
        self.quality_rules = None
        if config.quality_filter_rules_path:
            try:
                with open(config.quality_filter_rules_path, "r", encoding="utf-8") as f:
                    self.quality_rules = json.load(f)
                if self.is_main:
                    print(f"Loaded quality filter rules: {config.quality_filter_rules_path}")
            except Exception as e:
                if self.is_main:
                    print(f"Warning: failed to load quality filter rules ({config.quality_filter_rules_path}): {e}")
                self.quality_rules = None

        # Async data prefetching
        self._prefetch_requests = []
        self._prefetch_params_queue = []
        self.prefetcher = None
        if config.prefetch_workers > 0:
            self.prefetcher = DataPrefetcher(
                num_workers=config.prefetch_workers,
                prefetch_count=config.prefetch_count,
            )

        # GPU-batched ICL learnability filter: load a frozen LimiX checkpoint
        # onto the training GPU and run batched forward passes (~31ms for 8
        # episodes) instead of per-episode CPU inference in prefetch workers.
        self._icl_filter_model = None
        if config.icl_filter_model:
            self._init_gpu_icl_filter(config.icl_filter_model)

        # ICL filter telemetry — reset every log_interval, logged to wandb.
        # _icl_total_episodes:    denominator (episodes considered)
        # _icl_first_round_reject: numerator for reject_rate (failed initial filter)
        # _icl_escape_count:      slots that exhausted all replacement rounds;
        #                         the batch fails instead of training on them
        # _icl_rounds_used_sum:   sum of rounds-needed across all bad episodes;
        #                         ratio with first_round_reject = avg rounds.
        self._icl_total_episodes = 0
        self._icl_first_round_reject = 0
        self._icl_escape_count = 0
        self._icl_rounds_used_sum = 0

        self._set_target_aware_scale(self._get_current_target_aware_scale())

        # Wandb
        self.wandb_run = None
        self._resume_wandb = None

    # Shape buckets for torch.compile. These keep recompiles bounded while still
    # allowing larger late-curriculum tables.
    SAMPLE_BUCKETS = [
        64,
        128,
        256,
        512,
        768,
        1024,
        1536,
        2048,
        3072,
        4096,
        6144,
        8192,
        12288,
        16384,
        24576,
        32768,
        49152,
    ]
    FEATURE_BUCKETS = [4, 8, 16, 32, 48, 64, 96, 128, 192, 256, 320, 384, 512, 768, 1024]
    CONTEXT_RATIO_BUCKETS = [0.30, 0.40, 0.50, 0.60, 0.70, 0.80]

    @classmethod
    def _resolve_effective_shape_support(cls, cfg):
        """Return the exact bucketed shapes reachable by a configuration."""
        if cfg.shape_palette:
            shapes = tuple(
                (int(rows), int(features))
                for rows, features, _weight in cfg.shape_palette
                if int(rows) * int(features) <= cfg.max_sample_feature_budget
            )
        else:
            sample_buckets = tuple(
                int(value) for value in cls.SAMPLE_BUCKETS if cfg.min_samples <= int(value) <= cfg.max_samples
            )
            feature_buckets = tuple(
                int(value)
                for value in cls.FEATURE_BUCKETS
                if cfg.min_features <= int(value) <= cfg.max_features and int(value) % cfg.features_per_group == 0
            )
            shapes = tuple(
                (rows, features)
                for rows in sample_buckets
                for features in feature_buckets
                if rows * features <= cfg.max_sample_feature_budget
            )

        if not shapes:
            raise ValueError(
                "Configured random shape range contains no supported bucket: "
                f"rows={cfg.min_samples}..{cfg.max_samples}, "
                f"features={cfg.min_features}..{cfg.max_features}, "
                f"budget={cfg.max_sample_feature_budget}"
            )

        sample_buckets = tuple(sorted({rows for rows, _ in shapes}))
        feature_buckets = tuple(sorted({features for _, features in shapes}))
        return {
            "shapes": shapes,
            "sample_buckets": sample_buckets,
            "feature_buckets": feature_buckets,
            "min_samples": sample_buckets[0],
            "max_samples": sample_buckets[-1],
            "min_features": feature_buckets[0],
            "max_features": feature_buckets[-1],
        }

    def _sample_data_params(self):
        """Sample data generation parameters for one training step.

        Uses shared_rng so all DDP ranks get identical shape/task params.
        Also samples context_ratio here (before error-prone code) to keep
        shared_rng in sync even if generate_batch fails on one rank.
        """
        cfg = self.config
        rng = self.shared_rng  # Same across all ranks

        explicit_shape = bool(cfg.shape_palette)
        if explicit_shape:
            weights = np.asarray([entry[2] for entry in cfg.shape_palette], dtype=np.float64)
            weights /= weights.sum()
            shape_index = int(rng.choice(len(cfg.shape_palette), p=weights))
            n_samples, n_features, _weight = cfg.shape_palette[shape_index]
        elif cfg.fixed_n_samples is not None and cfg.fixed_n_features is not None:
            # Fixed size mode: skip random sampling but still consume rng
            # to keep shared_rng in sync with code that expects these draws.
            rng.uniform(0, 1)  # consume log_n_samples draw
            rng.uniform(0, 1)  # consume log_n_features draw
            n_samples = cfg.fixed_n_samples
            n_features = cfg.fixed_n_features
        else:
            # Biased log-uniform sampling: sample u ~ Uniform(0,1), raise to
            # power alpha (>1 biases toward max), then map to log-space range.
            # alpha=1.0 recovers standard log-uniform.
            log_min_s, log_max_s = np.log(cfg.min_samples), np.log(cfg.max_samples)
            u_s = rng.uniform(0, 1) ** (1.0 / cfg.dim_bias_samples)
            n_samples = int(np.exp(log_min_s + u_s * (log_max_s - log_min_s)))

            log_min_f, log_max_f = np.log(cfg.min_features), np.log(cfg.max_features)
            u_f = rng.uniform(0, 1) ** (1.0 / cfg.dim_bias_features)
            n_features = int(np.exp(log_min_f + u_f * (log_max_f - log_min_f)))
            if n_features % cfg.features_per_group != 0:
                n_features += cfg.features_per_group - (n_features % cfg.features_per_group)
            n_features = max(cfg.features_per_group, n_features)

        budget = cfg.max_sample_feature_budget
        if explicit_shape and n_samples * n_features > budget:
            raise ValueError(f"Explicit shape {n_samples}x{n_features} exceeds budget {budget}")
        if not explicit_shape and n_samples * n_features > budget:
            max_feat = budget // n_samples
            max_feat -= max_feat % cfg.features_per_group
            max_feat = max(cfg.features_per_group, max_feat)

            if max_feat >= cfg.features_per_group:
                n_features = min(n_features, max_feat)
            else:
                n_features = cfg.features_per_group
                n_samples = max(cfg.min_samples, budget // n_features)

        if not explicit_shape:
            support = self.effective_shape_support
            valid_s = [bucket for bucket in support["sample_buckets"] if bucket <= n_samples]
            valid_f = [bucket for bucket in support["feature_buckets"] if bucket <= n_features]
            n_samples = max(valid_s) if valid_s else support["min_samples"]
            n_features = max(valid_f) if valid_f else support["min_features"]

        if cfg.task_type == "both":
            task_type = "reg" if rng.random() < cfg.regression_ratio else "cls"
        else:
            rng.random()
            task_type = cfg.task_type

        n_classes = None
        if task_type == "cls":
            n_classes = int(rng.integers(cfg.min_classes, cfg.max_classes + 1))

        if cfg.context_ratio_palette:
            ratio_index = int(rng.integers(len(cfg.context_ratio_palette)))
            context_ratio = cfg.context_ratio_palette[ratio_index]
        else:
            context_ratio = rng.uniform(cfg.context_ratio_min, cfg.context_ratio_max)
            valid_cr = [
                cr for cr in self.CONTEXT_RATIO_BUCKETS if cr >= cfg.context_ratio_min and cr <= cfg.context_ratio_max
            ]
            if valid_cr:
                context_ratio = min(valid_cr, key=lambda cr: abs(cr - context_ratio))

        return n_samples, n_features, task_type, n_classes, context_ratio

    def _build_gen_kwargs(
        self,
        n_samples,
        n_features,
        task_type,
        n_classes,
        *,
        context_ratio=None,
    ):
        """Build keyword arguments dict for generate_batch from config."""
        cfg = self.config
        return {
            "batch_size": cfg.batch_size,
            "n_samples": n_samples,
            "n_features": n_features,
            "task_type": task_type,
            "n_classes": n_classes,
            "augment": cfg.synth_v2,
            "augment_v3": cfg.synth_v3,
            "rich_reg_targets": cfg.rich_reg_targets,
            # Context normalization removes positive affine target scaling.
            # Keep the dead transform off even for legacy configs that set it.
            "scale_variation": False,
            "augment_v4": cfg.synth_v4,
            "v4_filter": cfg.v4_filter,
            "learnability_filter": cfg.learnability_filter,
            "v4_no_edge_noise": cfg.v4_no_edge_noise,
            "synth_v5": cfg.synth_v5,
            "synth_v5_mixture": cfg.synth_v5_mixture,
            "reg_prior_prob": cfg.reg_prior_prob,
            "reg_denoise": cfg.reg_denoise,
            "reg_deterministic_prob": cfg.reg_deterministic_prob,
            "reg_dense": cfg.reg_dense,
            "scm_prior": cfg.scm_prior,
            "scm_prior_prob": cfg.scm_prior_prob,
            "probabilistic_labels": cfg.probabilistic_labels,
            "nominal_categoricals": cfg.nominal_categoricals,
            "enhanced_missingness": cfg.enhanced_missingness,
            "clean_lowdim_prob": cfg.clean_lowdim_prob,
            "tree_prior_prob": cfg.tree_prior_prob,
            "lookup_prior_prob": cfg.lookup_prior_prob,
            "quadratic_surface_prob": cfg.quadratic_surface_prob,
            "sparse_nonlinear_prob": cfg.sparse_nonlinear_prob,
            "gp_prior_prob": cfg.gp_prior_prob,
            "cat_dominant_prob": getattr(cfg, "cat_dominant_prob", 0.0),
            "binary_fingerprint_prob": getattr(cfg, "binary_fingerprint_prob", 0.0),
            "temporal_prior_prob": getattr(cfg, "temporal_prior_prob", 0.0),
            "train_feature_augment_prob": getattr(cfg, "train_feature_augment_prob", 0.0),
            "context_missingness_prob": cfg.context_missingness_prob,
            "realistic_augmentation_prob": cfg.realistic_augmentation_prob,
            "y_transform_prob": cfg.y_transform_prob,
            "cap_injection_prob": cfg.cap_injection_prob,
            "heavy_tail_prior_prob": cfg.heavy_tail_prior_prob,
            "pareto_importance_prob": cfg.pareto_importance_prob,
            "latent_factor_prob": cfg.latent_factor_prob,
            "high_cap_prob": cfg.high_cap_prob,
            "low_unique_y_prob": cfg.low_unique_y_prob,
            "learnability_filter_cls_min_score": cfg.learnability_filter_cls_min_score,
            "learnability_filter_cls_margin": cfg.learnability_filter_cls_margin,
            "learnability_filter_reg_min_score": cfg.learnability_filter_reg_min_score,
            "icl_scaling_filter": cfg.icl_scaling_filter,
            "icl_scaling_min_improvement": cfg.icl_scaling_min_improvement,
            "quality_rules": self.quality_rules,
            "filter_max_retries": cfg.quality_filter_max_retries,
            "context_rows": (
                min(max(1, int(n_samples * context_ratio)), n_samples - 1) if context_ratio is not None else None
            ),
        }

    def _get_current_feature_loss_weight(self) -> float:
        """Feature loss schedule in optimizer-step units."""
        cfg = self.config
        start = float(cfg.feature_loss_weight)
        end = cfg.feature_loss_weight_end
        if end is None or cfg.feature_loss_decay_end_step <= cfg.feature_loss_decay_start_step:
            return start

        step = int(self.optimizer_step)
        start_step = int(cfg.feature_loss_decay_start_step)
        end_step = int(cfg.feature_loss_decay_end_step)
        if step <= start_step:
            return start
        if step >= end_step:
            return float(end)

        alpha = (step - start_step) / max(end_step - start_step, 1)
        return float((1.0 - alpha) * start + alpha * float(end))

    def _get_current_target_aware_scale(self) -> float:
        """Warm up target-aware embedding from init_scale to 1.0."""
        cfg = self.config
        init_scale = float(cfg.target_aware_init_scale)
        warmup_steps = int(cfg.target_aware_warmup_steps)
        if warmup_steps <= 0:
            return 1.0

        step = min(max(int(self.optimizer_step), 0), warmup_steps)
        alpha = step / max(warmup_steps, 1)
        return float((1.0 - alpha) * init_scale + alpha * 1.0)

    def _set_target_aware_scale(self, scale: float) -> None:
        bare_model = self._get_bare_model()
        if hasattr(bare_model, "target_aware_scale"):
            bare_model.target_aware_scale = float(scale)

    def _submit_prefetch(
        self,
        n_samples,
        n_features,
        task_type,
        n_classes,
        context_ratio,
    ):
        """Submit one batch to the prefetcher with a deterministic seed."""
        seed = int(self.rng.integers(0, 2**63))
        gen_kwargs = self._build_gen_kwargs(
            n_samples,
            n_features,
            task_type,
            n_classes,
            context_ratio=context_ratio,
        )
        self.prefetcher.submit(seed=seed, gen_kwargs=gen_kwargs)
        self._prefetch_requests.append((seed, gen_kwargs))

    # ── GPU-batched ICL learnability filter ──────────────────────────────

    @staticmethod
    def _resolve_icl_filter_path(model_path: str) -> str:
        """Resolve shorthand names to a local file path.

        Accepted values:
          ``'limix'``         -- download LimiX-2M from ``stableai-org/LimiX-2M``
          ``'hf'``            -- download the default Synthefy checkpoint
          ``'org/repo'``      -- download from an arbitrary HuggingFace repo
          local file path     -- used as-is
        """
        if model_path == "limix":
            from synthefy_nori.hf import download_limix

            return download_limix()
        if model_path == "hf":
            from synthefy_nori.hf import download_checkpoint

            return download_checkpoint()
        if "/" in model_path and not os.path.exists(model_path):
            from synthefy_nori.hf import download_checkpoint

            return download_checkpoint(repo_id=model_path)
        return model_path

    def _init_gpu_icl_filter(self, model_path):
        """Load a frozen model for GPU-batched learnability filtering.

        Supports:
          - ``'hf'`` -- auto-download the default Synthefy checkpoint from HuggingFace
          - ``'org/repo'`` -- auto-download from a custom HuggingFace repo
          - Local file paths (.pt/.ckpt) -- uses native forward pass
        """
        model_path = self._resolve_icl_filter_path(model_path)
        from synthefy_nori.utils.loading import load_model

        m = load_model(model_path, mask_prediction=True)
        m.eval()
        m.to(self.device)
        for p in m.parameters():
            p.requires_grad_(False)
        self._icl_filter_model = m
        if self.is_main:
            print(f"GPU ICL filter: LimiX {model_path} -> {self.device}")

    @torch.no_grad()
    def _gpu_icl_filter(
        self,
        X_batch,
        y_batch,
        task_type="reg",
        n_classes=None,
        *,
        context_ratio=None,
    ):
        """Run batched ICL learnability check on GPU.

        Uses the frozen LimiX model (native forward). The model is loaded
        at init time by _init_gpu_icl_filter.

        Args:
            X_batch: np.ndarray [B, n_samples, n_features]
            y_batch: np.ndarray [B, n_samples]
            task_type: 'cls' or 'reg'
            n_classes: int or None

        Returns:
            passed: np.ndarray[bool] of shape [B] — True if episode is learnable
        """
        return self._gpu_icl_filter_limix(
            X_batch,
            y_batch,
            task_type,
            n_classes,
            context_ratio=context_ratio,
        )

    @staticmethod
    def _synthetic_episode_health_mask(
        X_batch,
        y_batch,
        n_ctx,
        *,
        task_type="reg",
    ):
        """Reject invalid numeric episodes before model-based filtering."""
        X_batch = np.asarray(X_batch)
        y_batch = np.asarray(y_batch)
        if X_batch.ndim != 3 or y_batch.ndim != 2:
            raise ValueError("ICL filter expects X=[B,N,F] and y=[B,N]")
        if X_batch.shape[:2] != y_batch.shape:
            raise ValueError(f"ICL filter X/y shape mismatch: X={X_batch.shape}, y={y_batch.shape}")
        if not 0 < n_ctx < X_batch.shape[1]:
            raise ValueError(f"ICL filter context rows must be in [1, N-1], got {n_ctx}")

        healthy = np.isfinite(y_batch).all(axis=1)
        healthy &= ~np.isinf(X_batch).any(axis=(1, 2))
        if task_type != "reg":
            return healthy

        y_ctx = y_batch[:, :n_ctx]
        y_qry = y_batch[:, n_ctx:]
        healthy &= np.ptp(y_ctx, axis=1) > 1e-8
        healthy &= np.ptp(y_qry, axis=1) > 1e-8

        x_ctx = X_batch[:, :n_ctx, :]
        ctx_finite = np.isfinite(x_ctx)
        finite_count = ctx_finite.sum(axis=1)
        ctx_min = np.min(np.where(ctx_finite, x_ctx, np.inf), axis=1)
        ctx_max = np.max(np.where(ctx_finite, x_ctx, -np.inf), axis=1)
        variable_ctx_feature = (
            (finite_count >= 2) & np.isfinite(ctx_min) & np.isfinite(ctx_max) & ((ctx_max - ctx_min) > 1e-8)
        )
        query_observed = np.isfinite(X_batch[:, n_ctx:, :]).any(axis=1)
        healthy &= np.any(variable_ctx_feature & query_observed, axis=1)
        return healthy

    def _gpu_icl_filter_limix(
        self,
        X_batch,
        y_batch,
        task_type="reg",
        n_classes=None,
        *,
        context_ratio=None,
    ):
        """Filter using frozen LimiX model (batched GPU forward pass).

        Uses the full dataset size (not a tiny subsample) so the filter
        decision matches what the training model will actually see.
        Processes one episode at a time to handle variable OOM risk.
        """
        cfg = self.config
        B, N, F = X_batch.shape

        # Score the exact sampled split used by the training step. A historical
        # fixed 70/30 gate could accept one boundary and train on another.
        filter_context_ratio = 0.7 if context_ratio is None else float(context_ratio)
        filter_context_ratio = min(max(filter_context_ratio, 0.05), 0.95)
        n_ctx = min(max(1, int(N * filter_context_ratio)), N - 1)
        n_qry = N - n_ctx

        passed = np.zeros(B, dtype=bool)
        healthy_idx = np.flatnonzero(
            self._synthetic_episode_health_mask(
                X_batch,
                y_batch,
                n_ctx,
                task_type=task_type,
            )
        )
        if len(healthy_idx) == 0:
            return passed

        X_sub = X_batch[healthy_idx].copy()
        y_sub = y_batch[healthy_idx].copy()

        X_sub = np.nan_to_num(X_sub, nan=0.0).astype(np.float32)

        if task_type == "cls":
            nc = min(n_classes or 10, 10)
            y_sub = np.clip(y_sub, 0, nc - 1).astype(np.float32)
        else:
            ctx_y = y_sub[:, :n_ctx]
            ctx_mean = np.mean(ctx_y, axis=-1, keepdims=True)
            ctx_std = np.std(ctx_y, axis=-1, keepdims=True)
            y_sub = ((y_sub - ctx_mean) / ctx_std).astype(np.float32)
            nc = None

        def _eval_batch(X_np, y_np):
            """Run filter on a batch slice, return R2 array or None on OOM."""
            try:
                x_t = torch.from_numpy(X_np).to(self.device)
                y_t = torch.from_numpy(y_np).to(self.device)
                with torch.autocast(
                    device_type=self.device.type,
                    dtype=torch.bfloat16,
                    enabled=self.device.type == "cuda",
                ):
                    out = self._icl_filter_model(
                        x_t,
                        y_t,
                        eval_pos=n_ctx,
                        task_type=task_type,
                    )
                if task_type == "cls":
                    logits = out["cls_output"][:, :n_qry, :nc].float().cpu().numpy()
                    preds = logits.argmax(axis=-1)
                    true = y_np[:, n_ctx : n_ctx + n_qry].astype(np.int64)
                    acc = (preds == true).mean(axis=-1)
                    chance = 1.0 / nc
                    margin = cfg.icl_filter_cls_min_auc - 0.5
                    return acc > (chance + margin)
                else:
                    preds = out["reg_output"][:, :n_qry, 0].float().cpu().numpy()
                    true = y_np[:, n_ctx : n_ctx + n_qry]
                    ss_res = ((true - preds) ** 2).sum(axis=-1)
                    ss_tot = ((true - true.mean(axis=-1, keepdims=True)) ** 2).sum(axis=-1)
                    r2 = 1.0 - ss_res / np.maximum(ss_tot, 1e-8)
                    return r2 > cfg.icl_filter_reg_min_r2
            except torch.cuda.OutOfMemoryError:
                torch.cuda.empty_cache()
                return None
            except RuntimeError as exc:
                if "out of memory" not in str(exc).lower():
                    raise
                torch.cuda.empty_cache()
                return None

        # Try full batch first (fastest)
        result = _eval_batch(X_sub, y_sub)
        if result is not None:
            passed[healthy_idx] = result
            return passed

        # OOM: fall back to per-episode
        for b, original_idx in enumerate(healthy_idx):
            result = _eval_batch(X_sub[b : b + 1], y_sub[b : b + 1])
            if result is None:
                raise RuntimeError(
                    "ICL filter OOM on a single episode; refusing to accept an unscored synthetic episode"
                )
            passed[original_idx] = result[0]

        return passed

    def _filter_and_replace(
        self,
        X_batch,
        y_batch,
        task_type="reg",
        n_classes=None,
        n_samples=None,
        n_features=None,
        context_ratio=None,
    ):
        """Filter a batch with GPU ICL and replace rejected episodes.

        Rejected episodes are regenerated synchronously (without ICL filter,
        since the replacement itself gets a GPU check on the next pass).
        Up to cfg.icl_filter_max_rounds (default 6) replacement rounds. If the
        budget is exhausted, fail the batch clearly rather than training on a
        candidate that the configured gate rejected.

        Telemetry counters (reset by the periodic log block):
          self._icl_total_episodes      — denominator
          self._icl_first_round_reject  — failed initial filter (numerator
                                          for reject_rate)
          self._icl_rounds_used_sum     — total rounds used across rejected
                                          episodes (avg = sum/reject_count)
          self._icl_escape_count        — slots that exhausted all rounds
                                          (numerator for exhaustion rate)
        """
        cfg = self.config
        max_rounds = max(1, int(getattr(cfg, "icl_filter_max_rounds", 6)))

        n_samples = int(n_samples or X_batch.shape[1])
        n_features = int(n_features or X_batch.shape[2])
        passed = self._gpu_icl_filter(
            X_batch,
            y_batch,
            task_type,
            n_classes,
            context_ratio=context_ratio,
        )
        n_rejected = int((~passed).sum())

        # Telemetry: count this batch toward the totals regardless of outcome.
        self._icl_total_episodes += len(passed)

        if n_rejected == 0:
            return X_batch, y_batch

        self._icl_first_round_reject += n_rejected

        if self.is_main and self.global_step % self.config.log_interval == 0:
            print(f"  [ICL-GPU] Rejected {n_rejected}/{len(passed)} episodes (round budget={max_rounds})")

        gen_kwargs = self._build_gen_kwargs(
            n_samples,
            n_features,
            task_type,
            n_classes,
            context_ratio=context_ratio,
        )
        gen_kwargs.pop("icl_filter_model", None)
        gen_kwargs.pop("batch_size", None)

        # Track per-episode "rounds needed". -1 means still bad after all
        # rounds; otherwise records 1..max_rounds (1 = passed after round 1).
        rounds_needed = np.where(passed, 0, -1)

        for round_idx in range(1, max_rounds + 1):
            bad_idx = np.where(~passed)[0]
            if len(bad_idx) == 0:
                break
            for i in bad_idx:
                rng_replace = np.random.default_rng(int(self.rng.integers(0, 2**63)))
                generated = generate_batch(batch_size=1, rng=rng_replace, **gen_kwargs)
                X_new, y_new = generated[:2]
                X_batch[i] = X_new[0]
                y_batch[i] = y_new[0]

            passed = self._gpu_icl_filter(
                X_batch,
                y_batch,
                task_type,
                n_classes,
                context_ratio=context_ratio,
            )
            # Episodes that just flipped from False to True passed at this round.
            newly_passed = passed & (rounds_needed == -1)
            rounds_needed[newly_passed] = round_idx

        good_rounds = rounds_needed[rounds_needed > 0]
        if len(good_rounds) > 0:
            self._icl_rounds_used_sum += int(good_rounds.sum())

        # Never turn retry exhaustion into implicit filter bypass.
        escape_idx = np.where(rounds_needed == -1)[0]
        if len(escape_idx) > 0:
            self._icl_escape_count += len(escape_idx)
            self._icl_rounds_used_sum += int(len(escape_idx) * max_rounds)
            raise ICLFilterExhaustedError(
                "ICL filter exhausted its replacement budget: "
                f"{len(escape_idx)}/{len(passed)} episode(s) still rejected "
                f"after {max_rounds} rounds"
            )

        return X_batch, y_batch

    def _apply_cat_target_encoding(self, X_batch, y_batch, eval_pos, p_col=0.25):
        """Replace cat-like columns with target-encoded versions per episode.

        Detection heuristic (per col, per episode):
          - Integer-valued (np.allclose to round)
          - unique_count <= 50

        For each detected cat col, with probability p_col, replace its values
        with mean(y_context) per category level. Unseen levels at query time
        get the global context-mean (sklearn TargetEncoder default).

        Uses CONTEXT rows only for the encoding so query y is never leaked
        through features.

        Args:
            X_batch: [B, N, F] (modified in place, returned)
            y_batch: [B, N] context-normalized regression targets
            eval_pos: int, context/query split point
            p_col: per-cat-col probability of swap
        """
        B, N, F = X_batch.shape
        for b in range(B):
            y_ctx = y_batch[b, :eval_pos]
            global_ctx_mean = float(np.nanmean(y_ctx)) if np.isfinite(y_ctx).any() else 0.0

            for j in range(F):
                col = X_batch[b, :, j]
                col_ctx = col[:eval_pos]
                finite = np.isfinite(col_ctx)
                if finite.sum() < 4:
                    continue

                vals = col_ctx[finite]
                unique_vals = np.unique(vals)
                if len(unique_vals) > 50:
                    continue
                # Integer check (cat protection)
                if not np.allclose(vals, np.round(vals), atol=1e-6):
                    continue

                if self.rng.random() >= p_col:
                    continue

                # Compute mean y per integer level (context only). Filter
                # NaN BEFORE round so NaN-cast-to-int doesn't trigger numpy's
                # "invalid value in cast" RuntimeWarning. NaN positions are
                # restored at the end (encoded[~finite] = nan).
                ctx_finite_mask = np.isfinite(col_ctx)
                col_ctx_safe = np.where(ctx_finite_mask, col_ctx, 0.0)
                rounded_ctx = np.round(col_ctx_safe).astype(np.int64)
                level_means = {}
                for lv in unique_vals:
                    lv_int = int(round(float(lv)))
                    mask = (rounded_ctx == lv_int) & ctx_finite_mask & np.isfinite(y_ctx)
                    if mask.any():
                        level_means[lv_int] = float(np.mean(y_ctx[mask]))

                # Apply to ALL rows (context + query). Query rows with unseen
                # levels get the global context-mean. Same NaN-safe rounding.
                full_finite_mask = np.isfinite(col)
                col_safe = np.where(full_finite_mask, col, 0.0)
                col_full_round = np.round(col_safe).astype(np.int64)
                encoded = np.full(N, global_ctx_mean, dtype=np.float64)
                for lv_int, mean_val in level_means.items():
                    encoded[col_full_round == lv_int] = mean_val
                # Preserve NaN positions
                encoded[~np.isfinite(col)] = np.nan

                # Re-standardize the encoded column to mean-0/std-1 over
                # context rows so it matches the model's expected input scale.
                enc_ctx = encoded[:eval_pos]
                enc_finite = enc_ctx[np.isfinite(enc_ctx)]
                if len(enc_finite) > 1:
                    mu = float(np.mean(enc_finite))
                    sd = float(np.std(enc_finite))
                    if sd > 1e-8:
                        encoded = (encoded - mu) / sd

                X_batch[b, :, j] = encoded.astype(X_batch.dtype)

        return X_batch

    def _apply_freq_count_encoding(self, X_batch, eval_pos, p_col=0.20):
        """Replace cat-like columns with frequency (count) encoding per episode.

        For real benchmarks with high-cardinality categorical IDs (chscase_foot,
        Goodreads, CookbookReviews), the label-encoded integer values carry no
        meaningful magnitude — but the COUNT of how often each value appears
        does. Common values are usually informative (e.g. popular product
        category); rare values are usually noise.

        Detection heuristic (per col, per episode):
          - Integer-valued (np.allclose to round)
          - unique_count <= 50

        For each detected cat col, with probability p_col, replace its values
        with count-of-occurrences in CONTEXT rows. Unseen levels in query get
        0 (rare-or-absent). Re-standardize for model input compatibility.

        Args:
            X_batch: [B, N, F] (modified in place, returned)
            eval_pos: int, context/query split point
            p_col: per-cat-col probability of swap
        """
        B, N, F = X_batch.shape
        for b in range(B):
            for j in range(F):
                col = X_batch[b, :, j]
                col_ctx = col[:eval_pos]
                finite = np.isfinite(col_ctx)
                if finite.sum() < 4:
                    continue

                vals = col_ctx[finite]
                unique_vals = np.unique(vals)
                if len(unique_vals) > 50:
                    continue
                # Integer check (cat protection)
                if not np.allclose(vals, np.round(vals), atol=1e-6):
                    continue

                if self.rng.random() >= p_col:
                    continue

                # Count occurrences per integer level (context only). NaN-safe.
                ctx_finite_mask = np.isfinite(col_ctx)
                col_ctx_safe = np.where(ctx_finite_mask, col_ctx, 0.0)
                rounded_ctx = np.round(col_ctx_safe).astype(np.int64)
                level_counts = {}
                for lv in unique_vals:
                    lv_int = int(round(float(lv)))
                    mask = (rounded_ctx == lv_int) & ctx_finite_mask
                    if mask.any():
                        level_counts[lv_int] = int(np.sum(mask))

                # Apply to all rows (context + query). Unseen levels in query
                # get 0 (genuinely informative — "this value didn't show up
                # in training").
                full_finite_mask = np.isfinite(col)
                col_safe = np.where(full_finite_mask, col, 0.0)
                col_full_round = np.round(col_safe).astype(np.int64)
                encoded = np.zeros(N, dtype=np.float64)
                for lv_int, count in level_counts.items():
                    encoded[col_full_round == lv_int] = float(count)
                # Preserve NaN positions
                encoded[~full_finite_mask] = np.nan

                # Re-standardize over context rows (matches model's expected
                # input scale, same as cat_target_encode).
                enc_ctx = encoded[:eval_pos]
                enc_finite = enc_ctx[np.isfinite(enc_ctx)]
                if len(enc_finite) > 1:
                    mu = float(np.mean(enc_finite))
                    sd = float(np.std(enc_finite))
                    if sd > 1e-8:
                        encoded = (encoded - mu) / sd

                X_batch[b, :, j] = encoded.astype(X_batch.dtype)

        return X_batch

    def _prepare_batch(self, X_batch, y_batch, task_type, n_classes, context_ratio):
        """Prepare a training batch with masking.

        Args:
            X_batch: [batch, n_samples, n_features]
            y_batch: [batch, n_samples]
            task_type: 'cls' or 'reg'
            n_classes: int or None
            context_ratio: float, pre-sampled from shared_rng for DDP sync

        Returns:
            x_input: [batch, seq_len, n_features] with masked values as NaN
            y_input: [batch, seq_len]
            eval_pos: int
            x_original: [batch, seq_len, n_features] unmasked
            feature_mask: [batch, seq_len, n_features]
            y_query: [batch, n_query] ground truth targets
        """
        cfg = self.config
        batch_size, n_samples, n_features = X_batch.shape

        # --- Column permutation (anti-memorization) ---
        # The SCM always places root nodes in early columns and downstream
        # nodes later. Without shuffling, the model can learn "attend to
        # later columns" as a shortcut instead of discovering feature
        # relationships in-context. Shuffle independently per episode.
        for b in range(batch_size):
            perm = self.rng.permutation(n_features)
            X_batch[b] = X_batch[b][:, perm]

        # --- Label permutation (classification anti-memorization) ---
        # Class labels from quantile bucketing always have class 0 = lowest
        # quantile, class N = highest. Without shuffling, the model learns
        # "class ordering = magnitude ordering" instead of treating labels
        # as arbitrary identifiers. Apply random bijection per episode.
        if task_type == "cls" and n_classes is not None and n_classes > 1:
            for b in range(batch_size):
                perm = self.rng.permutation(n_classes)
                y_int = y_batch[b].astype(np.int64).clip(0, n_classes - 1)
                y_batch[b] = perm[y_int].astype(np.float32)

        # Context/query split from pre-sampled ratio (synced across ranks)
        eval_pos = max(1, int(n_samples * context_ratio))
        eval_pos = min(eval_pos, n_samples - 1)  # At least 1 query row

        # Re-normalize regression targets from the actual sampled context.
        # Generators receive a planned context budget, while this boundary is
        # authoritative and remains the final inference-parity guard.
        if task_type == "reg":
            context_y = y_batch[:, :eval_pos]
            y_ctx_mean = context_y.mean(axis=-1, keepdims=True)
            y_ctx_std = context_y.std(axis=-1, keepdims=True)
            y_ctx_std = np.where(y_ctx_std < 1e-8, 1.0, y_ctx_std)
            y_batch = (y_batch - y_ctx_mean) / y_ctx_std

        # Cat target encoding (V12 audit-driven addition). Real benchmark
        # cat columns arrive in many encodings: label, ordinal, target-
        # encoded, etc. Synth pipeline almost always emits label-encoded
        # ints, so the model is brittle to other encodings. With probability
        # cat_target_encode_prob per col, replace a cat-like col with its
        # target-encoded version (mean-y per category) computed from CONTEXT
        # rows only — query y is masked, so no label leakage.
        cte_prob = float(getattr(cfg, "cat_target_encode_prob", 0.0))
        if cte_prob > 0.0 and task_type == "reg":
            X_batch = self._apply_cat_target_encoding(X_batch, y_batch, eval_pos, cte_prob)

        # Frequency / count encoding (V12r3 audit-driven addition).
        # For real benchmarks like chscase_foot (cat cardinality 236 in train,
        # 125 in test, 64 overlap) and Goodreads (high-cardinality
        # title/author cols), label-encoded integer levels are arbitrary
        # numbers — they don't carry meaningful magnitude. Replacing with
        # FREQUENCY (count of occurrences in context) extracts the genuinely
        # useful signal: "common values vs rare values". Unseen-in-train
        # levels naturally get count=0, which is informative.
        # Runs AFTER cat_target_encode so they don't both fire on the same
        # column (target encode produces continuous mean-y, breaking the
        # integer-check that gates freq encoding).
        fce_prob = float(getattr(cfg, "freq_count_encode_prob", 0.0))
        if fce_prob > 0.0 and task_type == "reg":
            X_batch = self._apply_freq_count_encoding(X_batch, eval_pos, fce_prob)

        n_query = n_samples - eval_pos

        # Create feature masks for query rows (per-rank rng for diversity).
        # Context rows are NOT masked here — context missingness is applied
        # during data generation instead (see _apply_context_missingness in
        # data_generator.py), which keeps the compiled graph stable because
        # the input data already contains NaNs when the compiler first traces.
        mask_type = random_mask_type(self.rng)
        mask_ratio = random_mask_ratio(cfg.mask_ratio_min, cfg.mask_ratio_max, self.rng)

        # Generate masks: [batch, n_query, n_features]
        feature_masks = []
        for _ in range(batch_size):
            m = create_masks(n_query, n_features, mask_ratio, mask_type, self.rng)
            feature_masks.append(m)
        query_mask = np.stack(feature_masks, axis=0)  # [B, n_query, n_features]

        # Full mask: context rows clean, query rows masked
        full_mask = np.zeros((batch_size, n_samples, n_features), dtype=bool)
        full_mask[:, eval_pos:, :] = query_mask

        # Apply masks to X
        x_original = X_batch.copy()
        x_masked = X_batch.copy()
        x_masked[full_mask] = np.nan

        # Convert to tensors
        x_input = torch.from_numpy(x_masked).float().to(self.device)
        y_input = torch.from_numpy(y_batch).float().to(self.device)
        x_original_t = torch.from_numpy(x_original).float().to(self.device)
        feature_mask_t = torch.from_numpy(full_mask).bool().to(self.device)
        y_query = torch.from_numpy(y_batch[:, eval_pos:]).float().to(self.device)

        return x_input, y_input, eval_pos, x_original_t, feature_mask_t, y_query

    def _log_diagnostics(self, output):
        """Print diagnostic information for debugging convergence."""
        # --- Gradient norms by component (after unscale, before clip) ---
        component_norms = {}
        n_zero = 0
        n_total = 0
        for name, p in self.model.named_parameters():
            if p.grad is None:
                continue
            n_total += 1
            norm = p.grad.data.norm(2).item()
            if norm == 0:
                n_zero += 1
            if not math.isfinite(norm):
                continue
            if "transformer_encoder" in name:
                key = "tfm"
            elif "cls_y_decoder" in name:
                key = "cls_dec"
            elif "reg_y_decoder" in name:
                key = "reg_dec"
            elif "feature_decoder" in name:
                key = "feat_dec"
            elif "encoder_x" in name:
                key = "x_enc"
            elif "cls_y_encoder" in name:
                key = "cls_enc"
            elif "reg_y_encoder" in name:
                key = "reg_enc"
            elif "x_preprocess" in name:
                key = "preproc"
            elif "feature_positional" in name:
                key = "feat_pos"
            else:
                key = "other"
            component_norms.setdefault(key, 0.0)
            component_norms[key] += norm**2

        component_norms = {k: v**0.5 for k, v in component_norms.items()}
        total_norm = sum(v**2 for v in component_norms.values()) ** 0.5

        scale = self.scaler.get_scale()
        parts = " ".join(f"{k}={v:.4e}" for k, v in sorted(component_norms.items()))
        print(f"  [DIAG] grad_norm={total_norm:.4e} scale={scale:.0f} zero_grad={n_zero}/{n_total}")
        print(f"  [DIAG] {parts}")

        # --- Output statistics ---
        if "cls_output" in output and output["cls_output"].numel() > 0:
            co = output["cls_output"].detach().float()
            probs = torch.softmax(co, dim=-1)
            max_prob = probs.max(dim=-1).values.mean()
            print(f"  [DIAG] cls: logit_mean={co.mean():.4f} logit_std={co.std():.4f} max_prob={max_prob:.4f}")
        if "reg_output" in output and output["reg_output"].numel() > 0:
            ro = output["reg_output"].detach().float()
            print(f"  [DIAG] reg: mean={ro.mean():.4f} std={ro.std():.4f}")

        feature_pred = output.get("feature_pred")
        if torch.is_tensor(feature_pred) and feature_pred.numel() > 0:
            fp = feature_pred.detach().float()
            print(f"  [DIAG] feat_pred: mean={fp.mean():.4f} std={fp.std():.4f}")

        # --- Process config sanity ---
        pc = output["process_config"]
        if pc.get("std_for_normalization") is not None:
            std_n = pc["std_for_normalization"].detach()
            n_zero_std = (std_n.abs() < 1e-6).sum().item()
            if n_zero_std > 0:
                print(f"  [DIAG] WARNING: {n_zero_std}/{std_n.numel()} near-zero std features")

    def _ddp_should_skip(self, should_skip):
        """In DDP, sync skip decision: if ANY rank wants to skip, ALL skip.

        This prevents deadlocks where one rank calls backward() (triggering
        all-reduce) while another rank skips it.
        """
        if not self.config.distributed:
            return should_skip
        skip_tensor = torch.tensor([1.0 if should_skip else 0.0], device=self.device)
        torch.distributed.all_reduce(skip_tensor, op=torch.distributed.ReduceOp.MAX)
        return skip_tensor.item() > 0.5

    def _ddp_step_status(self, should_skip, fatal_error):
        """Synchronize skip/fatal state before entering the next DDP phase."""
        if not self.config.distributed:
            return bool(should_skip), fatal_error is not None
        status = torch.tensor(
            [1 if should_skip else 0, 1 if fatal_error is not None else 0],
            device=self.device,
            dtype=torch.int32,
        )
        torch.distributed.all_reduce(status, op=torch.distributed.ReduceOp.MAX)
        return bool(status[0].item()), bool(status[1].item())

    def _raise_synchronized_step_error(self, fatal_error, phase):
        if not self.config.distributed and fatal_error is not None:
            raise fatal_error
        if fatal_error is not None:
            raise RuntimeError(
                f"Fatal {phase} error on rank {self.config.rank}: {type(fatal_error).__name__}: {fatal_error}"
            ) from fatal_error
        raise RuntimeError(f"Fatal {phase} error on another rank; see that rank's log")

    @staticmethod
    def _prefetch_worker_exception(error):
        """Reconstruct known worker outcomes without masking programming bugs."""
        if error.err_type == "SyntheticDataFilterError":
            return SyntheticDataFilterError(error.err_msg)
        if error.err_type == "ICLFilterExhaustedError":
            return ICLFilterExhaustedError(error.err_msg)
        return RuntimeError(f"Worker error ({error.err_type}): {error.err_msg}\n{error.tb}")

    def train_step(self):
        """Execute one training step with synchronized DDP phase boundaries.

        In DDP mode, all ranks are guaranteed to either all call backward()
        or all skip it. Bounded data/OOM outcomes skip; unexpected failures are
        raised on every rank before the next collective phase.

        Returns:
            loss_dict: dict with loss components, always includes 'skipped' key
        """
        self.model.train()
        cfg = self.config

        # --- Sample data parameters (shared_rng, consumed FIRST) ---
        # All shared_rng consumption happens here, before any error-prone code,
        # so even if generate_batch/forward fails on one rank, shared_rng stays
        # in sync across all ranks.
        if self.prefetcher is not None and hasattr(self, "_prefetch_params_queue") and self._prefetch_params_queue:
            # Async path: params were pre-sampled during prefill/previous step.
            n_samples, n_features, task_type, n_classes, context_ratio = self._prefetch_params_queue.pop(0)
        else:
            n_samples, n_features, task_type, n_classes, context_ratio = self._sample_data_params()

        current_feature_loss_weight = self._get_current_feature_loss_weight()
        current_tae_scale = self._get_current_target_aware_scale()
        self._set_target_aware_scale(current_tae_scale)

        # Build skip-result template
        def _skip_result():
            return {
                "total_loss": 0,
                "y_loss": 0,
                "feat_loss": 0,
                "skipped": True,
                "lr": self.scheduler.get_last_lr()[0],
                "task_type": task_type,
                "n_samples": n_samples,
                "n_features": n_features,
                "eval_pos": 0,
                "feature_loss_weight": current_feature_loss_weight,
                "target_aware_scale": current_tae_scale,
                "optimizer_stepped": False,
                "optimizer_step": self.optimizer_step,
            }

        should_skip = False
        fatal_error = None
        output = None
        loss = None
        loss_val = 0.0
        loss_dict = None
        eval_pos = 0

        # --- Generate/filter/prepare. Synchronize before any DDP forward. ---
        try:
            if self.prefetcher is not None:
                # Async path: get pre-generated batch from prefetcher.
                # The batch for THIS step was submitted earlier (in
                # _prefill_pipeline or previous train_step). We also
                # consume self.rng to keep it advancing (the seed was
                # already drawn when this batch was submitted).
                result = self.prefetcher.get()
                if self._prefetch_requests:
                    self._prefetch_requests.pop(0)
                from synthefy_nori.training.prefetch import _ErrorSentinel

                if isinstance(result, _ErrorSentinel):
                    raise self._prefetch_worker_exception(result)
                X_batch, y_batch, n_classes = result
            else:
                # Synchronous path (prefetch disabled)
                gen_kwargs = self._build_gen_kwargs(
                    n_samples,
                    n_features,
                    task_type,
                    n_classes,
                    context_ratio=context_ratio,
                )
                X_batch, y_batch, n_classes = generate_batch(
                    rng=self.rng,
                    **gen_kwargs,
                )

            # GPU-batched ICL learnability filter: single forward pass for
            # all episodes (~31ms for batch=8), replacing unlearnable ones.
            if self._icl_filter_model is not None:
                X_batch, y_batch = self._filter_and_replace(
                    X_batch, y_batch, task_type, n_classes, n_samples, n_features, context_ratio
                )

            x_input, y_input, eval_pos, x_original, feature_mask, y_query = self._prepare_batch(
                X_batch, y_batch, task_type, n_classes, context_ratio
            )

        except (ICLFilterExhaustedError, SyntheticDataFilterError) as error:
            if self.is_main:
                print(f"  [SKIP] Synthetic filter exhausted at step {self.global_step}: {error}")
            should_skip = True
        except RuntimeError as error:
            if "out of memory" in str(error).lower():
                if self.is_main:
                    print(
                        f"  [SKIP] OOM during data preparation at step "
                        f"{self.global_step} (n={n_samples}, f={n_features})"
                    )
                torch.cuda.empty_cache()
                should_skip = True
            else:
                fatal_error = error
                should_skip = True
        except Exception as error:
            fatal_error = error
            should_skip = True

        should_skip, fatal_any = self._ddp_step_status(
            should_skip,
            fatal_error,
        )
        if fatal_any:
            self._raise_synchronized_step_error(fatal_error, "data preparation")
        if should_skip:
            if cfg.gradient_accumulation <= 1:
                self.optimizer.zero_grad()
            return _skip_result()

        # Every rank has a prepared batch before any DDP forward begins.
        should_skip = False
        fatal_error = None
        try:
            # Forward pass
            with torch.autocast(device_type="cuda", dtype=torch.bfloat16, enabled=cfg.mixed_precision):
                output = self.model(
                    x=x_input,
                    y=y_input,
                    eval_pos=eval_pos,
                    task_type=task_type,
                )

            # Pull bar-borders buffer from model (may be None for non-bar
            # losses or if model wasn't built with bar_distribution head).
            _bare = self._get_bare_model()
            _bar_borders = getattr(_bare, "bar_borders_buffer", None)

            # Compute loss outside autocast for float32 precision
            loss, loss_dict = compute_ccmm_loss(
                model_output=output,
                y_true=y_query,
                x_original=x_original,
                feature_mask=feature_mask,
                task_type=task_type,
                n_classes=n_classes,
                feature_loss_weight=current_feature_loss_weight,
                regression_loss=cfg.regression_loss,
                regression_loss_beta=cfg.regression_loss_beta,
                regression_quantiles=cfg.regression_quantiles,
                pinball_tail_weight=cfg.pinball_tail_weight,
                pinball_monotonicity_weight=cfg.pinball_monotonicity_weight,
                pinball_mse_weight=cfg.pinball_mse_weight,
                num_bars=cfg.num_bars,
                bar_borders_low=cfg.bar_borders_low,
                bar_borders_high=cfg.bar_borders_high,
                bar_target_sigma=cfg.bar_target_sigma,
                bar_borders=_bar_borders,
                bar_target_sigma_y=getattr(cfg, "bar_target_sigma_y", 0.0),
                bar_aux_mse_weight=getattr(cfg, "bar_aux_mse_weight", 0.0),
                compile_pinball_loss=cfg.compile_pinball_loss,
            )
            loss_dict["feature_loss_weight"] = current_feature_loss_weight
            loss_dict["target_aware_scale"] = current_tae_scale

            loss_val = loss.item()

            # NaN / Inf check
            if not math.isfinite(loss_val):
                if self.is_main:
                    print(
                        f"  [SKIP] NaN/Inf loss at step {self.global_step} "
                        f"(task={task_type}, n={n_samples}, f={n_features})"
                    )
                should_skip = True

            # Loss spike check
            elif (
                self._loss_ema is not None
                and loss_val > self._loss_spike_threshold * self._loss_ema
                and self._loss_ema > 0
            ):
                if self.is_main:
                    y_l = loss_dict.get("y_loss", 0)
                    f_l = loss_dict.get("feat_loss", 0)
                    print(
                        f"  [SKIP] Loss spike at step {self.global_step}: "
                        f"{loss_val:.4f} > {self._loss_spike_threshold}x EMA "
                        f"({self._loss_ema:.4f}) "
                        f"[y={y_l:.2f} feat={f_l:.2f} task={task_type}]"
                    )
                should_skip = True

        except RuntimeError as error:
            if "out of memory" in str(error).lower():
                if self.is_main:
                    print(
                        f"  [SKIP] OOM during forward/loss at step {self.global_step} (n={n_samples}, f={n_features})"
                    )
                torch.cuda.empty_cache()
                should_skip = True
            else:
                fatal_error = error
                should_skip = True
        except Exception as error:
            fatal_error = error
            should_skip = True

        # Safety: if loss is None despite no exception, force skip
        if loss is None and not should_skip and fatal_error is None:
            if self.is_main:
                print(f"  [SKIP] loss=None at step {self.global_step}")
            should_skip = True

        # All ranks entered DDP forward before this second status sync. Fatal
        # local failures become fatal on every rank; bounded outcomes skip.
        should_skip, fatal_any = self._ddp_step_status(
            should_skip,
            fatal_error,
        )
        if fatal_any:
            self._raise_synchronized_step_error(fatal_error, "forward/loss")

        if should_skip:
            # During gradient accumulation, don't zero_grad on skip —
            # that would wipe accumulated gradients from prior micro-steps.
            # Just skip this micro-step's backward. zero_grad only happens
            # at optimizer step boundaries (line after scaler.step).
            if cfg.gradient_accumulation <= 1:
                self.optimizer.zero_grad()
            return _skip_result()

        # --- Update EMA (only for non-skipped steps) ---
        if self._loss_ema is None:
            self._loss_ema = loss_val
        else:
            self._loss_ema = self._loss_ema_alpha * loss_val + (1 - self._loss_ema_alpha) * self._loss_ema

        # --- Backward pass ---
        # In DDP mode, backward triggers gradient all-reduce across ranks.
        # If one rank OOMs mid-backward, the all-reduce is partially done,
        # permanently desyncing NCCL. So we don't catch backward OOM in DDP —
        # the budget should be set low enough to prevent it.
        if loss is None:
            # Defensive: should never reach here (skip logic above handles it)
            # but prevents crash if DDP sync race condition lets it through
            self.optimizer.zero_grad()
            return _skip_result()

        # Scale loss by gradient accumulation steps so effective gradient
        # is the mean across micro-batches (not the sum).
        if cfg.gradient_accumulation > 1:
            loss = loss / cfg.gradient_accumulation

        # Ensure all parameters participate in the backward graph so DDP
        # can use find_unused_parameters=False.  The model conditionally
        # skips cls or reg encoder/decoder depending on task_type, which
        # would otherwise leave those params without gradients and trigger
        # a DDP hang (or a PyTorch >=2.10 is_pinned assertion failure with
        # find_unused_parameters=True).  Adding 0 * sum(p) creates autograd
        # edges without changing the gradient values.
        if cfg.distributed:
            raw_model = self.model.module if hasattr(self.model, "module") else self.model
            loss = loss + 0.0 * sum(p.sum() for p in raw_model.parameters() if p.requires_grad)

        # Use no_sync() for intermediate gradient accumulation steps.
        # Without this, DDP triggers all_reduce on every backward() call,
        # and timing differences between ranks cause NCCL desync/timeout.
        next_accum_count = self.accumulated_micro_steps + 1
        is_accum_step = next_accum_count < cfg.gradient_accumulation
        use_no_sync = cfg.distributed and is_accum_step and cfg.gradient_accumulation > 1

        if cfg.distributed:
            ctx = self.model.no_sync() if use_no_sync else nullcontext()
            with ctx:
                self.scaler.scale(loss).backward()
        else:
            try:
                self.scaler.scale(loss).backward()
            except RuntimeError as e:
                if "out of memory" in str(e).lower():
                    print(f"  [SKIP] OOM in backward at step {self.global_step} (n={n_samples}, f={n_features})")
                    torch.cuda.empty_cache()
                    self.optimizer.zero_grad()
                    self.accumulated_micro_steps = 0
                    return _skip_result()
                raise

        self.accumulated_micro_steps = next_accum_count
        optimizer_stepped = False
        if self.accumulated_micro_steps >= cfg.gradient_accumulation:
            # Gradient clipping
            self.scaler.unscale_(self.optimizer)

            # Debug NPZ dump: capture unscaled, pre-clip gradients for the
            # first debug_dump_steps optimizer steps (reproduction harness).
            _dbg_dump = bool(cfg.debug_dump_dir) and self.is_main and self.optimizer_step < cfg.debug_dump_steps
            _dbg_grads = None
            if _dbg_dump:
                _dbg_grads = {
                    n: p.grad.detach().float().cpu().numpy()
                    for n, p in self._get_bare_model().named_parameters()
                    if p.grad is not None
                }

            # Diagnostics (after unscaling, before clipping) — rank 0 only
            if cfg.log_interval > 0 and ((self.optimizer_step + 1) % cfg.log_interval == 0) and self.is_main:
                self._log_diagnostics(output)

            grad_norm = torch.nn.utils.clip_grad_norm_(self.model.parameters(), cfg.gradient_clip)

            self.scaler.step(self.optimizer)
            self.scaler.update()
            self.optimizer.zero_grad()
            self.scheduler.step()
            self._update_ema()
            self.accumulated_micro_steps = 0
            self.optimizer_step += 1
            optimizer_stepped = True

            if _dbg_dump:
                self._write_debug_dump(
                    step=self.optimizer_step - 1,
                    X_batch=X_batch,
                    y_batch=y_batch,
                    x_input=x_input,
                    y_input=y_input,
                    eval_pos=eval_pos,
                    loss_val=loss_val,
                    loss_dict=loss_dict,
                    grad_norm=float(grad_norm),
                    grads=_dbg_grads,
                )

        loss_dict["skipped"] = False
        loss_dict["lr"] = self.scheduler.get_last_lr()[0]
        loss_dict["task_type"] = task_type
        loss_dict["n_samples"] = n_samples
        loss_dict["n_features"] = n_features
        loss_dict["eval_pos"] = eval_pos
        loss_dict["optimizer_stepped"] = optimizer_stepped
        loss_dict["optimizer_step"] = self.optimizer_step

        return loss_dict

    def _write_debug_dump(
        self, *, step, X_batch, y_batch, x_input, y_input, eval_pos, loss_val, loss_dict, grad_norm, grads
    ):
        """Write one per-step NPZ for the reproduction harness.

        Observation-only — runs only when config.debug_dump_dir is set. Each
        file holds the raw generated batch, the model-ready input tensors,
        loss scalars, unscaled pre-clip gradients, and post-step weights.
        init_weights.npz (pre-training weights) is written once by train().
        """
        d = self.config.debug_dump_dir
        os.makedirs(d, exist_ok=True)
        bare = self._get_bare_model()

        def _np_of(t):
            if isinstance(t, torch.Tensor):
                return t.detach().float().cpu().numpy()
            return np.asarray(t)

        payload = {
            "X_batch": _np_of(X_batch),
            "y_batch": _np_of(y_batch),
            "x_input": _np_of(x_input),
            "y_input": _np_of(y_input),
            "eval_pos": np.int64(eval_pos),
            "loss": np.float64(loss_val),
            "grad_norm": np.float64(grad_norm),
        }
        for k, v in (loss_dict or {}).items():
            if isinstance(v, bool):
                continue
            if isinstance(v, (int, float)):
                payload[f"loss_dict.{k}"] = np.float64(v)
            elif isinstance(v, torch.Tensor) and v.ndim == 0:
                payload[f"loss_dict.{k}"] = np.float64(v.item())
        for n, g in (grads or {}).items():
            payload[f"grad.{n}"] = g
        for n, p in bare.named_parameters():
            payload[f"weight.{n}"] = p.detach().float().cpu().numpy()

        path = os.path.join(d, f"step{step}.npz")
        np.savez(path, **payload)
        print(f"  [debug-dump] step {step} -> {path} ({len(payload)} arrays)")

    def _get_bare_model(self):
        """Return the unwrapped model (handles DDP and torch.compile wrapping)."""
        model = self.model
        # Unwrap DDP
        if hasattr(model, "module"):
            model = model.module
        # Unwrap torch.compile
        if hasattr(model, "_orig_mod"):
            model = model._orig_mod
        return model

    def _clone_current_model_state(self):
        return {name: tensor.detach().clone() for name, tensor in self._get_bare_model().state_dict().items()}

    def _update_ema(self):
        if self.ema_state_dict is None:
            return

        with torch.no_grad():
            current_state = self._get_bare_model().state_dict()
            if self.config.ema_foreach:
                _foreach_ema_update(
                    self.ema_state_dict,
                    current_state,
                    self.ema_decay,
                )
                return
            for name, tensor in current_state.items():
                ema_tensor = self.ema_state_dict[name]
                if torch.is_floating_point(tensor):
                    ema_tensor.mul_(self.ema_decay).add_(tensor.detach(), alpha=1.0 - self.ema_decay)
                else:
                    ema_tensor.copy_(tensor)

    def _local_runtime_state(self):
        """Snapshot rank-local streams plus recipes for unconsumed worker batches."""
        state = {
            "shared_rng": copy.deepcopy(self.shared_rng.bit_generator.state),
            "rng": copy.deepcopy(self.rng.bit_generator.state),
            "python_rng": random.getstate(),
            "numpy_rng": np.random.get_state(),
            "torch_rng": torch.get_rng_state(),
            "cuda_rng": torch.cuda.get_rng_state(self.device) if self.device.type == "cuda" else None,
            "prefetch_requests": copy.deepcopy(self._prefetch_requests),
            "prefetch_params": copy.deepcopy(self._prefetch_params_queue),
        }
        state["sampling"] = {"_loss_ema": self._loss_ema}
        return state

    def _checkpoint_runtime_states(self):
        state = self._local_runtime_state()
        if not self.config.distributed:
            return [state]
        states = [None] * torch.distributed.get_world_size()
        torch.distributed.all_gather_object(states, state)
        return states

    def _restore_runtime_state(self, state):
        self.shared_rng.bit_generator.state = state["shared_rng"]
        self.rng.bit_generator.state = state["rng"]
        random.setstate(state["python_rng"])
        np.random.set_state(state["numpy_rng"])
        torch.set_rng_state(state["torch_rng"].cpu())
        if state["cuda_rng"] is not None and self.device.type == "cuda":
            torch.cuda.set_rng_state(state["cuda_rng"].cpu(), self.device)
        for name, value in state["sampling"].items():
            if torch.is_tensor(value):
                value = value.to(self.device)
            setattr(self, name, value)
        self._prefetch_requests = state["prefetch_requests"]
        self._prefetch_params_queue = state["prefetch_params"]
        if self._prefetch_requests and self.prefetcher is None:
            warnings.warn(
                "Prefetch disabled on resume; discarding pending batches and continuing the saved RNG streams."
            )
            self._prefetch_requests = []
            self._prefetch_params_queue = []

    def _discard_incompatible_sampling_state(self, saved_config):
        """Explicit data/shape overrides take effect before the first resumed batch."""
        saved = saved_config if isinstance(saved_config, dict) else vars(saved_config)
        shape_fields = (
            "fixed_n_samples",
            "fixed_n_features",
            "min_samples",
            "max_samples",
            "min_features",
            "max_features",
            "features_per_group",
            "max_sample_feature_budget",
            "dim_bias_samples",
            "dim_bias_features",
            "shape_palette",
            "context_ratio_min",
            "context_ratio_max",
            "context_ratio_palette",
        )
        shapes_changed = any(name in saved and saved[name] != getattr(self.config, name) for name in shape_fields)
        generation_changed = False
        for params, (_seed, queued_kwargs) in zip(self._prefetch_params_queue, self._prefetch_requests):
            current = self._build_gen_kwargs(*params[:4], context_ratio=params[4])
            generation_changed |= any(queued_kwargs.get(key) != value for key, value in current.items())
        generation_changed |= saved.get("prefetch_count", self.config.prefetch_count) != self.config.prefetch_count
        if (shapes_changed or generation_changed) and self._prefetch_requests:
            warnings.warn(
                "Data settings changed on resume; discarding pending batches and continuing saved RNG streams."
            )
            self._prefetch_requests = []
            self._prefetch_params_queue = []

    def _start_training_prefetch(self):
        self.prefetcher.start()
        # Regenerate queued batches without advancing either trainer RNG.
        for seed, kwargs in self._prefetch_requests:
            self.prefetcher.submit(seed=seed, gen_kwargs=kwargs)
        for _ in range(max(0, self.config.prefetch_count - len(self._prefetch_params_queue))):
            params = self._sample_data_params()
            self._prefetch_params_queue.append(params)
            self._submit_prefetch(*params)

    def save_checkpoint(self, path=None):
        """Gather runtime state on all ranks; write the checkpoint on rank 0."""
        runtime_states = self._checkpoint_runtime_states()
        if not self.is_main:
            return

        if path is None:
            os.makedirs(self.config.checkpoint_dir, exist_ok=True)
            path = os.path.join(self.config.checkpoint_dir, f"checkpoint_step_{self.global_step}.pt")

        save_dict = {
            "model_state_dict": self._get_bare_model().state_dict(),
            "optimizer_state_dict": self.optimizer.state_dict(),
            "scheduler_state_dict": self.scheduler.state_dict(),
            "scaler_state_dict": self.scaler.state_dict(),
            "global_step": self.global_step,
            "optimizer_step": self.optimizer_step,
            "accumulated_micro_steps": self.accumulated_micro_steps,
            "best_loss": self.best_loss,
            "config": self.config,
            "runtime_states": runtime_states,
            "wandb_run": (
                {"id": self.wandb_run.id, "project": self.wandb_run.project, "entity": self.wandb_run.entity}
                if self.wandb_run is not None
                else self._resume_wandb
            ),
        }
        if self.ema_state_dict is not None:
            save_dict["ema_state_dict"] = self.ema_state_dict
            save_dict["ema_decay"] = self.ema_decay
        if self.model_config is not None:
            save_dict["model_config"] = self.model_config
        # Publish only complete archives: the launcher chooses the highest
        # checkpoint_step_*.pt, and an interrupted write must not replace a
        # resumable checkpoint or leave a partial higher-step candidate.
        checkpoint_path = Path(path)
        with tempfile.TemporaryDirectory(dir=checkpoint_path.parent, prefix=f".{checkpoint_path.name}.") as directory:
            temporary_path = Path(directory) / checkpoint_path.name
            torch.save(save_dict, temporary_path)
            try:
                existing_mode = stat.S_IMODE(checkpoint_path.stat().st_mode)
            except FileNotFoundError:
                pass
            else:
                temporary_path.chmod(existing_mode)
            os.replace(temporary_path, checkpoint_path)
        print(f"Checkpoint saved to {path}")
        if self.on_checkpoint_saved is not None:
            self.on_checkpoint_saved()

    def load_checkpoint(self, path, model_only: bool = False):
        """Load a training checkpoint.

        After loading, evaluates the current schedule at the saved position,
        including any explicitly changed base LR.
        """
        ckpt = torch.load(path, map_location=self.device, weights_only=False)
        # strict=False allows new optional parameters (e.g. column_y_aware_alpha
        # added 2026-05-03 for V10) to be loaded from their fresh init when
        # FT'ing from older checkpoints. Missing/unexpected keys are logged so
        # the user notices unintended schema mismatches.
        missing, unexpected = self._get_bare_model().load_state_dict(ckpt["model_state_dict"], strict=False)
        if (missing or unexpected) and self.is_main:
            if missing:
                print(f"  [load_checkpoint] missing keys (using fresh init): {missing}")
            if unexpected:
                print(f"  [load_checkpoint] unexpected keys (ignored): {unexpected}")

        if model_only:
            # Fresh optimizer/scheduler state is required when a curriculum stage
            # intentionally restarts its LR schedule from the loaded weights.
            self.optimizer.zero_grad()
            self.global_step = 0
            self.optimizer_step = 0
            self.accumulated_micro_steps = 0
            self.best_loss = float("inf")
            if self.ema_state_dict is not None:
                loaded_ema = ckpt.get("ema_state_dict")
                if loaded_ema is None:
                    self.ema_state_dict = self._clone_current_model_state()
                else:
                    # Merge: prefer loaded EMA values, but fall back to current
                    # model state for any key the older checkpoint didn't have
                    # (e.g., V10's column_y_aware_alpha when FT'ing from V8old).
                    current_state = self._clone_current_model_state()
                    for k in current_state:
                        if k in loaded_ema:
                            current_state[k] = loaded_ema[k]
                    self.ema_state_dict = current_state
            self._set_target_aware_scale(self._get_current_target_aware_scale())
            if self.is_main:
                print(f"Checkpoint weights loaded from {path}; optimizer, scheduler, scaler, and step counters reset.")
            return

        self.optimizer.load_state_dict(ckpt["optimizer_state_dict"])
        self.scheduler.load_state_dict(ckpt["scheduler_state_dict"])
        self.scaler.load_state_dict(ckpt["scaler_state_dict"])
        self.global_step = ckpt["global_step"]
        self.optimizer_step = ckpt.get("optimizer_step", max(self.scheduler.last_epoch - 1, 0))
        loaded_accumulated_micro_steps = ckpt.get("accumulated_micro_steps", 0)
        # Checkpoints do not serialize in-flight parameter gradients, so resuming
        # mid accumulation would otherwise step with missing micro-batch grads.
        self.accumulated_micro_steps = 0
        self.best_loss = ckpt.get("best_loss", float("inf"))
        if self.ema_state_dict is not None:
            loaded_ema = ckpt.get("ema_state_dict")
            if loaded_ema is None:
                self.ema_state_dict = self._clone_current_model_state()
            else:
                current_state = self._clone_current_model_state()
                for k in current_state:
                    if k in loaded_ema:
                        current_state[k] = loaded_ema[k]
                self.ema_state_dict = current_state
        self._set_target_aware_scale(self._get_current_target_aware_scale())

        # LambdaLR.load_state_dict restores counters, not the current schedule's
        # LR. Set the value used by the very next optimizer update without taking
        # an extra scheduler step (which would shift all subsequent updates).
        new_lr = self.config.lr
        self.optimizer.defaults["lr"] = new_lr
        self.scheduler.base_lrs = [new_lr] * len(self.optimizer.param_groups)
        for pg, lr_lambda in zip(self.optimizer.param_groups, self.scheduler.lr_lambdas):
            pg["initial_lr"] = new_lr
            pg["lr"] = new_lr * lr_lambda(self.scheduler.last_epoch)
        self.scheduler._last_lr = [pg["lr"] for pg in self.optimizer.param_groups]
        self.optimizer.zero_grad()
        self._resume_wandb = ckpt.get("wandb_run")
        runtime_states = ckpt.get("runtime_states")
        if runtime_states is not None:
            rank = torch.distributed.get_rank() if self.config.distributed else 0
            world_size = torch.distributed.get_world_size() if self.config.distributed else 1
            if len(runtime_states) != world_size:
                raise ValueError("Full resume requires the checkpoint world size to restore per-rank RNG streams")
            self._restore_runtime_state(runtime_states[rank])
            if ckpt.get("config") is not None:
                self._discard_incompatible_sampling_state(ckpt["config"])
        else:
            # Old checkpoints cannot reproduce the continuation exactly. Avoid
            # replaying their opening stream and make that limitation visible.
            warnings.warn("Checkpoint has no RNG state; continuing with fresh step-seeded streams (not exact replay).")
            self.shared_rng = np.random.default_rng([self.config.seed, self.global_step, 1])
            self.rng = np.random.default_rng([self.config.seed, self.global_step, self.config.rank, 2])

        if self.is_main:
            if loaded_accumulated_micro_steps:
                print(
                    "Checkpoint had "
                    f"accumulated_micro_steps={loaded_accumulated_micro_steps}; "
                    "reset to 0 because accumulated gradients are not serialized."
                )
            print(f"Checkpoint loaded from {path}, step={self.global_step}, lr={new_lr:.2e}")

    def train(self):
        """Main training loop."""
        cfg = self.config

        if cfg.use_wandb and self.is_main:
            try:
                import wandb

                wandb_kwargs = {
                    "project": cfg.wandb_project,
                    "config": vars(cfg),
                }
                if cfg.wandb_entity:
                    wandb_kwargs["entity"] = cfg.wandb_entity
                if cfg.wandb_name:
                    wandb_kwargs["name"] = cfg.wandb_name
                if cfg.wandb_group:
                    wandb_kwargs["group"] = cfg.wandb_group
                if cfg.wandb_job_type:
                    wandb_kwargs["job_type"] = cfg.wandb_job_type
                if cfg.wandb_tags:
                    wandb_kwargs["tags"] = list(cfg.wandb_tags)
                if self._resume_wandb is not None:
                    if os.environ.get("WANDB_RUN_ID") not in (None, self._resume_wandb["id"]):
                        raise ValueError("WANDB_RUN_ID differs from the checkpoint's W&B run")
                    wandb_kwargs.update(self._resume_wandb, resume="must")
                self.wandb_run = wandb.init(
                    **wandb_kwargs,
                )
            except ImportError:
                print("wandb not installed, disabling logging")
                cfg.use_wandb = False
            except Exception as e:
                if self._resume_wandb is not None:
                    raise RuntimeError("resumed training requires W&B initialization to succeed") from e
                print(f"wandb init failed ({e}), disabling logging")
                cfg.use_wandb = False

        # Gradient accumulation: all user-facing params (total_steps, warmup,
        # decay, save/eval/log intervals) are in OPTIMIZER STEP units.
        # Accumulation windows are counted by successful micro-batches only, so
        # skipped micro-steps don't silently change the effective batch size.
        accum = cfg.gradient_accumulation
        start_optimizer_step = self.optimizer_step
        if cfg.run_steps is not None:
            target_optimizer_step = min(
                cfg.total_steps,
                start_optimizer_step + cfg.run_steps,
            )
        else:
            target_optimizer_step = cfg.total_steps

        if self.is_main:
            print(f"Starting training for {cfg.total_steps} optimizer steps")
            if cfg.run_steps is not None:
                planned_steps = max(target_optimizer_step - start_optimizer_step, 0)
                print(
                    f"  This invocation: {planned_steps} optimizer steps "
                    f"(from {start_optimizer_step} to {target_optimizer_step})"
                )
            if accum > 1:
                print(f"  Gradient accumulation: {accum} successful micro-steps per optimizer step")
            print(f"  Device: {cfg.device}")
            print(f"  Batch size: {cfg.batch_size}")
            if cfg.distributed:
                print(f"  World size: {cfg.world_size}")
                eff_batch = cfg.batch_size * cfg.world_size * accum
                print(f"  Effective batch size: {eff_batch}")
            print(f"  Learning rate: {cfg.lr}")
            if (
                cfg.feature_loss_weight_end is not None
                and cfg.feature_loss_decay_end_step > cfg.feature_loss_decay_start_step
            ):
                print(
                    f"  Feature loss schedule: {cfg.feature_loss_weight:.3f} -> "
                    f"{cfg.feature_loss_weight_end:.3f} "
                    f"(steps {cfg.feature_loss_decay_start_step}.."
                    f"{cfg.feature_loss_decay_end_step})"
                )
            else:
                print(f"  Feature loss weight: {cfg.feature_loss_weight:.3f}")
            if cfg.target_aware_warmup_steps > 0:
                print(
                    f"  Target-aware warmup: scale {cfg.target_aware_init_scale:.3f} -> 1.000 "
                    f"over {cfg.target_aware_warmup_steps} steps"
                )
            print(f"  Mixed precision: {cfg.mixed_precision}")
            if cfg.compile:
                print(f"  torch.compile: enabled")
            if self.prefetcher is not None:
                print(f"  Async prefetch: {cfg.prefetch_workers} workers, {cfg.prefetch_count} prefetch")

        if target_optimizer_step <= start_optimizer_step:
            if self.is_main:
                print(
                    f"No training steps to run: optimizer_step={start_optimizer_step}, target={target_optimizer_step}."
                )
            if cfg.use_wandb and self.wandb_run:
                import wandb

                wandb.finish()
            return

        # --- Start prefetcher and pre-fill pipeline ---
        if self.prefetcher is not None and self.optimizer_step < target_optimizer_step:
            self._start_training_prefetch()
        else:
            self._prefetch_params_queue = []

        running_loss = 0.0
        running_y_loss = 0.0
        running_feat_loss = 0.0
        running_cls_y_loss = 0.0
        running_reg_y_loss = 0.0
        cls_count = 0
        reg_count = 0
        log_count = 0
        start_time = time.time()

        self.optimizer.zero_grad()

        if self.global_step == 0 and self.optimizer_step == 0:
            with warnings.catch_warnings():
                warnings.filterwarnings("ignore", message=".*lr_scheduler.step.*")
                self.scheduler.step()  # Initialize scheduler at step 0

        first_log_pending = self.global_step == 0 and self.optimizer_step == 0

        # Debug NPZ dump: snapshot initial weights once, before any step.
        if self.config.debug_dump_dir and self.is_main and self.optimizer_step == 0:
            os.makedirs(self.config.debug_dump_dir, exist_ok=True)
            _bare = self._get_bare_model()
            _init = {f"weight.{n}": p.detach().float().cpu().numpy() for n, p in _bare.named_parameters()}
            np.savez(os.path.join(self.config.debug_dump_dir, "init_weights.npz"), **_init)
            print(f"  [debug-dump] init weights -> {self.config.debug_dump_dir}/init_weights.npz ({len(_init)} params)")

        while self.optimizer_step < target_optimizer_step:
            # train_step handles all errors internally (OOM, ValueError, NaN,
            # spike) and syncs skip decisions across DDP ranks. Never raises
            # except for truly fatal errors.
            loss_dict = self.train_step()
            self.global_step += 1

            # Submit next prefetch batch (keep pipeline full).
            if self.prefetcher is not None and self.optimizer_step < target_optimizer_step:
                params = self._sample_data_params()
                ns, nf, tt, nc, cr = params
                self._prefetch_params_queue.append(params)
                self._submit_prefetch(ns, nf, tt, nc, cr)

            if not loss_dict.get("skipped", False):
                running_loss += loss_dict["total_loss"]
                running_y_loss += loss_dict["y_loss"]
                running_feat_loss += loss_dict["feat_loss"]
                log_count += 1
                # Per-task-type loss tracking
                if loss_dict.get("task_type") == "cls":
                    running_cls_y_loss += loss_dict["y_loss"]
                    cls_count += 1
                elif loss_dict.get("task_type") == "reg":
                    running_reg_y_loss += loss_dict["y_loss"]
                    reg_count += 1

            stepped = loss_dict.get("optimizer_stepped", False)
            should_log = False
            if log_count > 0 and self.is_main:
                if first_log_pending:
                    should_log = True
                    first_log_pending = False
                elif stepped and cfg.log_interval > 0 and self.optimizer_step % cfg.log_interval == 0:
                    should_log = True
            if should_log and log_count > 0 and self.is_main:
                elapsed = time.time() - start_time
                avg_loss = running_loss / log_count
                avg_y = running_y_loss / log_count
                avg_feat = running_feat_loss / log_count
                n_steps_elapsed = log_count
                steps_per_sec = n_steps_elapsed / elapsed
                opt_step = self.optimizer_step

                print(
                    f"Step {opt_step}/{cfg.total_steps} | "
                    f"loss={avg_loss:.4f} y={avg_y:.4f} feat={avg_feat:.4f} | "
                    f"lr={loss_dict['lr']:.2e} | "
                    f"feat_w={loss_dict.get('feature_loss_weight', cfg.feature_loss_weight):.3f} "
                    f"tae={loss_dict.get('target_aware_scale', 1.0):.3f} | "
                    f"{steps_per_sec:.1f} steps/s | "
                    f"task={loss_dict['task_type']} "
                    f"n={loss_dict['n_samples']} f={loss_dict['n_features']}"
                )

                if cfg.use_wandb and self.wandb_run:
                    import wandb

                    log_dict = {
                        "train/loss": avg_loss,
                        "train/y_loss": avg_y,
                        "train/feat_loss": avg_feat,
                        "train/lr": loss_dict["lr"],
                        "train/feature_loss_weight": loss_dict.get("feature_loss_weight", cfg.feature_loss_weight),
                        "train/target_aware_scale": loss_dict.get("target_aware_scale", 1.0),
                        "train/steps_per_sec": steps_per_sec,
                        "data/n_samples": loss_dict["n_samples"],
                        "data/n_features": loss_dict["n_features"],
                    }
                    if cls_count > 0:
                        log_dict["train/cls_y_loss"] = running_cls_y_loss / cls_count
                    if reg_count > 0:
                        log_dict["train/reg_y_loss"] = running_reg_y_loss / reg_count
                    # ICL-filter telemetry — only emit when we saw episodes
                    # this window (denominator > 0). Resets immediately below.
                    if self._icl_total_episodes > 0:
                        denom = float(self._icl_total_episodes)
                        reject_rate = self._icl_first_round_reject / denom
                        exhaustion_rate = self._icl_escape_count / denom
                        log_dict["train/icl_filter_reject_rate"] = reject_rate
                        log_dict["train/icl_filter_exhaustion_rate"] = exhaustion_rate
                        log_dict["train/icl_filter_episodes"] = int(self._icl_total_episodes)
                        if self._icl_first_round_reject > 0:
                            avg_rounds = self._icl_rounds_used_sum / float(self._icl_first_round_reject)
                            log_dict["train/icl_filter_avg_rounds"] = avg_rounds
                        # Echo the rates to stdout — operators care about
                        # Exhaustion is a bounded skip, never silent acceptance.
                        print(
                            f"  [ICL-GPU/win] reject={reject_rate * 100:.1f}% "
                            f"exhausted={exhaustion_rate * 100:.2f}% "
                            f"(over {int(denom)} eps)"
                        )
                    wandb.log(log_dict, step=opt_step)

                # Reset ICL-filter counters at every log window so each metric
                # describes the most-recent log_interval steps. Reset on rank-0
                # only because they're rank-local; in DDP each rank tracks its
                # own filter passes.
                self._icl_total_episodes = 0
                self._icl_first_round_reject = 0
                self._icl_escape_count = 0
                self._icl_rounds_used_sum = 0

                running_loss = 0.0
                running_y_loss = 0.0
                running_feat_loss = 0.0
                running_cls_y_loss = 0.0
                running_reg_y_loss = 0.0
                cls_count = 0
                reg_count = 0
                log_count = 0
                start_time = time.time()

            # Checkpoint saving (on optimizer step boundaries)
            if stepped and cfg.save_interval > 0 and self.optimizer_step % cfg.save_interval == 0:
                self.save_checkpoint()

        # Final checkpoint
        self.save_checkpoint()

        # Shutdown prefetcher
        if self.prefetcher is not None:
            self.prefetcher.shutdown()

        if cfg.use_wandb and self.wandb_run:
            import wandb

            wandb.finish()

        if self.is_main:
            if self.optimizer_step >= cfg.total_steps:
                print("Training complete!")
            else:
                print(f"Training segment complete at optimizer step {self.optimizer_step}/{cfg.total_steps}.")

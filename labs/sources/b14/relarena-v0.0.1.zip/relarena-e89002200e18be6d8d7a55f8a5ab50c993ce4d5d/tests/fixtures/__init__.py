"""Test-only contributor fixtures."""

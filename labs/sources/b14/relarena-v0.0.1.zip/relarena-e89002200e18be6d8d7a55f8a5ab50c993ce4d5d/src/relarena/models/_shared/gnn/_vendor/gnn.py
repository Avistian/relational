# ruff: noqa
# SPDX-License-Identifier: MIT
# Copyright (c) 2023 RelBench Team
# Vendored from snap-stanford/relbench @ 74d4c37; full license text in
# models/VENDORED-LICENSES.
"""Vendored RelBench GNN building blocks — the shared core for relarena's GNN baselines.

This module is a **faithful copy** of RelBench's example GNN code. It lives here because
``examples/`` is not part of the installable ``relbench`` package (it is ``__main__``
training scripts with relative imports, so it cannot be imported). relarena's GNN
baselines (``graphsage`` now; RelGNN / RelGT later) import ``Model`` /
``GloveTextEmbedding`` from here, and keep their own relarena glue (the fit/predict
contract, splits, search space, graph cache, loaders) in the model modules — not here.

Source — vendored from **snap-stanford/relbench @ commit 74d4c37**:
  * ``Model``              <- examples/model.py
    https://github.com/snap-stanford/relbench/blob/74d4c37/examples/model.py
  * ``GloveTextEmbedding`` <- examples/text_embedder.py
    https://github.com/snap-stanford/relbench/blob/74d4c37/examples/text_embedder.py

The class bodies are kept verbatim (the two files' imports are merged here; ruff only
normalizes formatting). This file is lint-exempt (``# ruff: noqa``) so it stays a clean
diff against upstream — to re-sync, re-copy from the pinned files and bump the commit
above. The GNN layers themselves (``HeteroEncoder`` / ``HeteroGraphSAGE`` / ``HeteroGAT``
/ ``HeteroTemporalEncoder``) are imported from the installed ``relbench.modeling.nn``,
not copied.
"""

from typing import Any, Dict, List, Optional

import torch
from sentence_transformers import SentenceTransformer
from torch import Tensor
from torch.nn import Embedding, ModuleDict
from torch_frame.data.stats import StatType
from torch_geometric.data import HeteroData
from torch_geometric.nn import MLP
from torch_geometric.typing import NodeType

from relbench.modeling.nn import (
    HeteroEncoder,
    HeteroGAT,
    HeteroGraphSAGE,
    HeteroTemporalEncoder,
)


class GloveTextEmbedding:
    def __init__(self, device: Optional[torch.device] = None):
        self.model = SentenceTransformer(
            "sentence-transformers/average_word_embeddings_glove.6B.300d",
            device=device,
        )

    def __call__(self, sentences: List[str]) -> Tensor:
        # Some RelBench datasets can contain missing values in text columns.
        # SentenceTransformers tokenizers expect strings.
        cleaned: List[str] = []
        for s in sentences:
            if s is None:
                cleaned.append("")
            elif isinstance(s, str):
                cleaned.append(s)
            else:
                # Handle NaN/float/other scalars.
                try:
                    if isinstance(s, float) and s != s:  # NaN
                        cleaned.append("")
                    else:
                        cleaned.append(str(s))
                except Exception:
                    cleaned.append("")
        return self.model.encode(cleaned, convert_to_tensor=True)


class Model(torch.nn.Module):
    def __init__(
        self,
        data: HeteroData,
        col_stats_dict: Dict[str, Dict[str, Dict[StatType, Any]]],
        num_layers: int,
        channels: int,
        out_channels: int,
        aggr: str,
        norm: str,
        # List of node types to add shallow embeddings to input
        shallow_list: List[NodeType] = [],
        # ID awareness
        id_awareness: bool = False,
        gnn: str = "sage",
        gat_heads: int = 4,
        gat_dropout: float = 0.0,
    ):
        super().__init__()

        self.encoder = HeteroEncoder(
            channels=channels,
            node_to_col_names_dict={
                node_type: data[node_type].tf.col_names_dict
                for node_type in data.node_types
            },
            node_to_col_stats=col_stats_dict,
        )
        self.temporal_encoder = HeteroTemporalEncoder(
            node_types=[
                node_type for node_type in data.node_types if "time" in data[node_type]
            ],
            channels=channels,
        )
        gnn = str(gnn).lower()
        if gnn == "sage":
            self.gnn = HeteroGraphSAGE(
                node_types=data.node_types,
                edge_types=data.edge_types,
                channels=channels,
                aggr=aggr,
                num_layers=num_layers,
            )
        elif gnn == "gat":
            self.gnn = HeteroGAT(
                node_types=data.node_types,
                edge_types=data.edge_types,
                channels=channels,
                heads=gat_heads,
                num_layers=num_layers,
                dropout=gat_dropout,
            )
        else:
            raise ValueError(f"Unknown gnn={gnn!r}. Expected 'sage' or 'gat'.")
        self.head = MLP(
            channels,
            out_channels=out_channels,
            norm=norm,
            num_layers=1,
        )
        self.embedding_dict = ModuleDict(
            {
                node: Embedding(data.num_nodes_dict[node], channels)
                for node in shallow_list
            }
        )

        self.id_awareness_emb = None
        if id_awareness:
            self.id_awareness_emb = torch.nn.Embedding(1, channels)
        self.reset_parameters()

    def reset_parameters(self):
        self.encoder.reset_parameters()
        self.temporal_encoder.reset_parameters()
        self.gnn.reset_parameters()
        self.head.reset_parameters()
        for embedding in self.embedding_dict.values():
            torch.nn.init.normal_(embedding.weight, std=0.1)
        if self.id_awareness_emb is not None:
            self.id_awareness_emb.reset_parameters()

    def forward(
        self,
        batch: HeteroData,
        entity_table: NodeType,
    ) -> Tensor:
        seed_time = batch[entity_table].seed_time
        x_dict = self.encoder(batch.tf_dict)

        rel_time_dict = self.temporal_encoder(
            seed_time, batch.time_dict, batch.batch_dict
        )

        for node_type, rel_time in rel_time_dict.items():
            x_dict[node_type] = x_dict[node_type] + rel_time

        for node_type, embedding in self.embedding_dict.items():
            x_dict[node_type] = x_dict[node_type] + embedding(batch[node_type].n_id)

        x_dict = self.gnn(
            x_dict,
            batch.edge_index_dict,
            batch.num_sampled_nodes_dict,
            batch.num_sampled_edges_dict,
        )

        return self.head(x_dict[entity_table][: seed_time.size(0)])

    def forward_dst_readout(
        self,
        batch: HeteroData,
        entity_table: NodeType,
        dst_table: NodeType,
    ) -> Tensor:
        if self.id_awareness_emb is None:
            raise RuntimeError(
                "id_awareness must be set True to use forward_dst_readout"
            )
        seed_time = batch[entity_table].seed_time
        x_dict = self.encoder(batch.tf_dict)
        # Add ID-awareness to the root node
        x_dict[entity_table][: seed_time.size(0)] += self.id_awareness_emb.weight

        rel_time_dict = self.temporal_encoder(
            seed_time, batch.time_dict, batch.batch_dict
        )

        for node_type, rel_time in rel_time_dict.items():
            x_dict[node_type] = x_dict[node_type] + rel_time

        for node_type, embedding in self.embedding_dict.items():
            x_dict[node_type] = x_dict[node_type] + embedding(batch[node_type].n_id)

        x_dict = self.gnn(
            x_dict,
            batch.edge_index_dict,
        )

        return self.head(x_dict[dst_table])

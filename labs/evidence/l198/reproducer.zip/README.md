# L198 complete proposal audit
Python 3.12 recommended. From this extracted directory:

    python3 -m venv .venv
    .venv/bin/python -m pip install -r requirements-audit.txt
    .venv/bin/python labs/_budget_l198.py .venv/bin/python labs/_audit_l198.py
    .venv/bin/python labs/_budget_l198.py .venv/bin/python labs/_verify_l198.py

CPU only; no model calls. The budget wrapper caps its attempts together at 1800 seconds; account environment preparation separately in your own ledger. Output labs/evidence/l198/report.json must match the supplied reference. All original inputs and independent verifiers are included. Models NOT_RUN; novelty NOT_ESTABLISHED; learner defense pending.

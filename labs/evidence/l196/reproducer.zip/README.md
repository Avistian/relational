# L196 complete original-preprocessor diagnostic

Python 3.12, CPU, no checkpoints or API calls. Internet is needed only to install pinned dependencies.
From this extracted directory:
    python3 -m venv .venv
    .venv/bin/python -m pip install -r requirements-diagnostic.txt
    .venv/bin/python -m pip check
    .venv/bin/python diagnostic.py .

The script verifies every source hash, imports the original full preprocessor and runs all four cases.
It writes diagnostic.json (fresh). saved-diagnostic.json contains the author's measured output for comparison.
No changed encoder or simplified substitute is installed. This is not benchmark reproduction.

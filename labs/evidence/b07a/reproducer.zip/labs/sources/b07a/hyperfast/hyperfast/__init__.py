from .hyperfast import HyperFastClassifier

B01 saved-evidence audit. Install NumPy, then python labs/_audit_b01.py and python labs/_verify_b01.py. No model inference.

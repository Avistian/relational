# L197 complete landscape evidence audit

Python 3.12 recommended. CPU; no model weights or external API calls. From this extracted directory:

    python3 -m venv .venv
    .venv/bin/python -m pip install -r requirements-audit.txt
    .venv/bin/python labs/_budget_l197.py .venv/bin/python labs/_audit_l197.py
    .venv/bin/python labs/_budget_l197.py .venv/bin/python labs/_verify_l197.py

The budget wrapper caps all its runs together at 1800 seconds. Installation is environment preparation; the author's preparation is included in the repository ledger. Account your own preparation time separately. The audit reconstructs the full selected tables and rescored predictions. Fresh model reproduction remains incomplete. All inputs and original sources are hash checked. Independent verifiers run in temporary copies. Output: labs/evidence/l197/report.json and labs/_verify_l197_results.json. This is replay, not an independent replication.

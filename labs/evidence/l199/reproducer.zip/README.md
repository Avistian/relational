# L199 complete direction selection audit

Python 3.12 recommended. Extract this archive, create an environment and install requirements-audit.txt. Account installation/preparation in your own budget. Then from the extracted directory:

    python3 labs/_budget_l199.py python3 labs/_audit_l199.py
    python3 labs/_budget_l199.py python3 labs/_verify_l199.py

The wrapper caps aggregate subprocess execution at 1800 seconds, including failures, and kills the process group at cutoff. Add your preparation allowance to the ledger before execution. USD0 cloud/API. All inputs and source versions are frozen. Output report must equal the included report exactly. Independent verification runs in a disposable copy. No model training, inference or new literature collection; fresh model reproduction remains INCOMPLETE_SOURCE_PREPROCESSING_GATE. Complete replay is not independent replication. See protocol.json and l199-reproduction.md.
